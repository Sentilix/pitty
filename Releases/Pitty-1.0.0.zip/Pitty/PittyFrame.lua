﻿--[[
	Author:			Mimma
	Create Date:	5/23/2016 4:59:42 PM	
]]

local PARTY_CHANNEL = "PARTY"
local RAID_CHANNEL  = "RAID"
local YELL_CHANNEL  = "YELL"
local SAY_CHANNEL   = "SAY"
local WARN_CHANNEL  = "RAID_WARNING"
local GUILD_CHANNEL = "GUILD"
local CHAT_END      = "|r"
local COLOUR_CHAT   = "|c8040A0F8"
local COLOUR_INTRO  = "|c8080F0FF"


-- List of QH detected players: { playername, count, healed }
local QHPlayers = { }


--[[
	Echo a message for the local user only, including "logo"
]]
local function echo(msg)
	if msg then
		DEFAULT_CHAT_FRAME:AddMessage(COLOUR_CHAT .. msg .. CHAT_END)
	end
end

local function gEcho(msg)
	echo("<"..COLOUR_INTRO.."PiTTY"..COLOUR_CHAT.."> "..msg);
end

local function sayEcho(msg)
	SendChatMessage(msg, SAY_CHANNEL);
end

local function yellEcho(msg)
	SendChatMessage(msg, YELL_CHANNEL);
end

local function rwEcho(msg)
	SendChatMessage(msg, WARN_CHANNEL);
end

local function partyEcho(msg)
	SendChatMessage(msg, PARTY_CHANNEL);
end

local function raidEcho(msg)
	SendChatMessage(msg, RAID_CHANNEL);
end

function guildEcho(msg)
	SendChatMessage(msg, GUILD_CHANNEL)
end

function addonEcho(msg)
	SendAddonMessage(PITTY_MESSAGE_PREFIX, msg, "RAID")
end

local function whisper(receiver, msg)
	SendChatMessage(msg, WHISPER_CHANNEL, nil, receiver);
end

local function customEcho(channel, msg)
	if not channel then
		channel = "";
	else
		channel = string.upper(channel);
	end
	
	if channel == "SAY" then
		sayEcho(msg);
	elseif channel == "YELL" then
		yellEcho(msg);
	elseif channel == "PARTY" then
		partyEcho(msg);
	elseif channel == "RAID" then
		raidEcho(msg);
	elseif channel == "RW" then
		rwEcho(msg);
	elseif channel == "GUILD" then
		guildEcho(msg);
	else
		gEcho(msg);
	end

end


--[[
	Main entry for Thaliz.
	This will send the request to one of the sub slash commands.
	Syntax: /thaliz [option, defaulting to "res"]
	Added in: 0.0.1
]]
SLASH_PITTY_PITTY1 = "/pitty"
SlashCmdList["PITTY_PITTY"] = function(msg)
	local _, _, option = string.find(msg, "(%s+)");
	args = "";

	if not option or option == "" then
		option = "HELP"
	end
	option = string.upper(option);
		
	if (option == "HELP" or option == "?") then
		gEcho("Help incoming!");
	elseif option == "STATS" then
		Pitty_ShowStats(args);
	elseif option == "VERSION" then
		gEcho("PiTTY version " .. GetAddOnMetadata("PiTTY", "Version") .. " by ".. GetAddOnMetadata("PiTTY", "Author"))
	else
		gEcho(string.format("Unknown command: %s", option));
	end
end


--[[
	Main entry for Thaliz.
	This will send the request to one of the sub slash commands.
	Syntax: /thaliz [option, defaulting to "res"]
	Added in: 0.0.1
]]
SLASH_PITTY_STATS1 = "/pittystats"
SLASH_PITTY_STATS2 = "/qhstats"
SlashCmdList["PITTY_STATS"] = function(msg)
	local _, _, args = string.find(msg, "(%S*)");
	if not args or args == "" then
		args = "LOCAL";
	end

	Pitty_ShowStats(args);
end


function Pitty_SortTableDescending(sourcetable, index)
	local doSort = true
	while doSort do
		doSort = false
		for n=1,table.getn(sourcetable) - 1, 1 do
			local a = sourcetable[n]
			local b = sourcetable[n + 1]
			if (a[index]) < (b[index]) then
				sourcetable[n] = b
				sourcetable[n + 1] = a
				doSort = true
			end
		end
	end
	return sourcetable;
end



local function Pitty_RegisterQHeal(playername, healed)
		
	for n=1, table.getn(QHPlayers), 1 do
		if QHPlayers[n][1] == playername then
			QHPlayers[n][2] = QHPlayers[n][2] + 1;
			QHPlayers[n][3] = QHPlayers[n][3] + (1* healed);
			return;
		end
	end
	
	-- Player not found; add him/her:	
	QHPlayers[ table.getn(QHPlayers) + 1] = { playername, 1, healed };
	gEcho(string.format("Detected new QH player: %s (healing for %d)", playername, healed));
end


function Pitty_ShowStats(channel)
	customEcho(channel, "QuickHeal Stats:");

	local sortedTable = Pitty_SortTableDescending(QHPlayers, 3);
	local playername, healed, count;
	for n=1, table.getn(sortedTable), 1 do
		playername = QHPlayers[n][1];
		count = QHPlayers[n][2];
		healed = QHPlayers[n][3];
			
		customEcho(channel, string.format("%d: %s (%d healed / %d average)", n, playername, healed, round(healed / count) ));
	end
end



local function Pitty_OnChatMsgAddon(event, prefix, msg, channel, sender)
    if arg1 == "Panza" or arg1 == "QuickHeal" or arg1 == "Heart" or arg1 == "Genesis" then
		--echo(string.format("QH: %s > %s", sender, msg));
		local _, _, healed = string.find(msg, "[^,]+, (%d+)");
		Pitty_RegisterQHeal(sender, healed);
    end
end



--
--	Events
--
function Pitty_OnEvent(event, arg1, arg2, arg3, arg4, arg5)
	if (event == "CHAT_MSG_ADDON") then
		Pitty_OnChatMsgAddon(event, arg1, arg2, arg3, arg4, arg5)
	end
end



function Pitty_OnLoad()
	gEcho("PiTTY version " .. GetAddOnMetadata("PiTTY", "Version") .. " by ".. GetAddOnMetadata("PiTTY", "Author"))

    this:RegisterEvent("CHAT_MSG_ADDON")    
end
